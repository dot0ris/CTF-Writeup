#!/bin/sh
sudo docker build -t terpsichore .