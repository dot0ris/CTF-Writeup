#!/bin/sh
sudo docker run --name terpsichore -d --restart unless-stopped -p 38207:38207 terpsichore