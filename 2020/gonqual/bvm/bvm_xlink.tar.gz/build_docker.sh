#!/bin/sh
sudo docker build -t bvm_xlink .