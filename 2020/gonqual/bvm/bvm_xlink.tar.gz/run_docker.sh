#!/bin/sh
sudo docker run --name bvm_xlink -d --restart unless-stopped -p 63650:63650 bvm_xlink